package edu.ncsu.ieee.botcontrol;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.content.Context;
/**
 * Created by Andrew on 7/23/2015.
 */
public class RPLidar extends View{
    private Paint mapPaint;
    private int points[] = new int[360];
    private int loopCtrl = 0;
    double XPoint = 0;
    double YPoint = 0;
    double deg;

    private float centerX = 0.f;   ///< Center X position
    private float centerY = 0.f;   ///< Center Y position

    public RPLidar(Context context){
        super(context);
        init(null, 0);
    }
    public RPLidar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs, 0);
    }
    public RPLidar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs, defStyle);
    }

    private void init(AttributeSet attrs, int defStyle) {
        mapPaint = new Paint();
        mapPaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        mapPaint.setStyle(Paint.Style.FILL);
        mapPaint.setColor(Color.argb(200, 0, 0, 255));
        for(int i = 0; i < 360; i++) {
            points[i] = 5;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for(loopCtrl = 0, deg=0; loopCtrl < 360; loopCtrl++, deg+= Math.PI/180) {
            XPoint = Math.cos(deg) * points[loopCtrl]/10;
            YPoint = Math.sin(deg) * points[loopCtrl]/10;

            canvas.drawPoint(centerX + (float)XPoint, centerY + (float)YPoint,mapPaint );
        }
    // TODO Consider storing these as member variables to reduce allocations per draw cycle
    int paddingLeft = getPaddingLeft();
    int paddingTop = getPaddingTop();
    int paddingRight = getPaddingRight();
    int paddingBottom = getPaddingBottom();

    int contentWidth = getWidth() - paddingLeft - paddingRight;
    int contentHeight = getHeight() - paddingTop - paddingBottom;

    }

    public void setPoints(int[] pts) {
        for(loopCtrl = 0; loopCtrl < pts.length; loopCtrl++) {
            points[loopCtrl] = pts[loopCtrl];
        }
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        if (w == 0 || h == 0)
            return; // invalid width/height, nothing to do

        centerX = w / 2.f;
        centerY = h / 2.f;
    }
}
